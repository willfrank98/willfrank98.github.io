TeamBuilder by Will Frank

See SampleInput.csv for an example of the appropriate input format

TODO (high priority to low):
-handle more edge cases
-group siblings/coaches and children together
-take availability into account
-make GUI
-account for spelling mistakes
